module.exports = {
  TOKEN: "yourToken",
  ACTIVITY: `yourBotActivity`,
  devGuild: "yourTestGuild",
  developer: ["yourID"],
}
