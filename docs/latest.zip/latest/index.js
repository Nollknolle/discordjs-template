const { Client, Intents } = require("discord.js");
const {
  TOKEN,
  ACTIVITY,
  devGuild,
  developer,
} = require("./config/Config");
const fs = require("fs");

const cmd = new Map();

var client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES],
  partials: ["MESSAGE", "CHANNEL", "REACTION"],
});

const CommandFiles = fs
  .readdirSync("./commands")
  .filter((files) => files.endsWith(".js"));
for (const file of CommandFiles) {
  const command = require(`./commands/${file}`);

  cmd.set(command.name, command);
  console.log(`Command set: ${command.name}`);
}

// Deployment
client.on("messageCreate", async (message) => {
  if (!client.application?.owner) await client.application?.fetch();
  if (!developer.includes(message.author.id)) return;

  if (message.content.toLowerCase() === "!deployguild") {
    //Guild deployment
    const data = Array.from(cmd, ([name, value]) => value).map((c) => ({
      name: c.name,
      description: c.description,
      options: c.options,
    }));
    const command = await client.guilds.cache.get(devGuild)?.commands.set(data);

    message.reply({
      content: "Deployment successfully guild base.",
    });
  }
});

client.on("interactionCreate", async (interaction) => {
  if (interaction.isCommand()) {
    const command = cmd.get(interaction.commandName);
    if (command) {
      command.execute(interaction);
    }
  }
});

client.login(TOKEN);
client.on("ready", () => {
  console.log("Bot status: started");
  client.user.setActivity(ACTIVITY, {
    type: "PLAYING",
  });
});
