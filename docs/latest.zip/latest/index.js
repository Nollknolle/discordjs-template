const Discord = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("./utils/config.json");
const pckjson = require("./package.json");


var client = new Discord.Client();

client.commands = new Discord.Collection();
const CommandFiles = fs
  .readdirSync("./commands/")
  .filter((files) => files.endsWith(".js"));
for (const file of CommandFiles) {
  const command = require(`./commands/${file}`);

  client.commands.set(command.name, command);
}

client.on("message", (message) => {
  if (!message.content.startsWith(config.PREFIX) || message.author.bot) return;

  const args = message.content.slice(config.PREFIX.length).split(/ +/);
  const cmd = client.commands.get(args.shift().toLowerCase());
  if (cmd) {
    cmd.execute(message, args);
  }
});

client.login(config.TOKEN);
client.on("ready", () => {
  console.log(`Logged in as ${client.user.tag}!`);
  client.user.setActivity(`[${config.PREFIX}] // Version: ${pckjson.version}`, {
    type: "WATCHING",
  });
});
