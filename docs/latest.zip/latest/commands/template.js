module.exports = {
  name: "template",
  description: "I am a Template",
  async execute(interaction) {
    interaction.reply({ content: "Hey" });
  },
};
