const Discord = require("discord.js");
const fs = require("fs");

module.exports = {
  name: "command",
  description: "This is a command!",
  async execute(message, args) {
  },
};